Install the Mouse Client APK on your Android phone. You might need to "allow installation of apps from unknown sources".

Pair your Bluetooth enabled phone with your computer. This is necessary for the app to work.

Run "run server.bat" on your computer. Set the sensitivity to whatever you want (1 is normal; 0.5 halves the sensitivity; 2 doubles it). Connect to the server using the Phone Mouse app.